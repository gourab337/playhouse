#include<bits/stdc++.h>
#include<algorithm>

using namespace std;

#define mp make_pair
#define pb push_back
#define ff first
#define ss second

const double pi=3.1415926535897932384626433832;
const long long mod=1e9+7;
//long long primeset[5000000]={};
typedef complex<double> cd;
typedef long long ll;
typedef double ld;
//#define For(i,0,n) for(long long i = 0 ; i<n ;i++)
//#define uppertolower if(isupper(a[i]))  {a[i] = a[i] + 32;}

/*void removeCharsFromString( string &str, char* charsToRemove ) {
   for ( unsigned int i = 0; i < strlen(charsToRemove); ++i ) {
      str.erase( remove(str.begin(), str.end(), charsToRemove[i]), str.end() ); }}*/

//atoi()- char array to integer typecast STL, changes original string, keep copy
//itoi() - int to char array typecast:  sprintf(str,"%d",value)
//============================================================================================================================================


int main()
{
	ios_base::sync_with_stdio(false); cin.tie(NULL); cout.tie(NULL);

int T,N; 
cin>>T; int profit2=0,profit=0; 

int a[4][4], b[4];

while(T--)
{   int h=100;
   for(int i=0; i<4; i++)
   {
      for(int j=0; j<4; j++)
         a[i][j]=0;
   }

   cin>>N; char movie; int ti;
      for(int i=0; i<N; i++)
      {
         cin>>movie>>ti;
         int movie1;
         movie1=(int)(movie)-65;
         
         
         switch(ti)
         {
            case 12:  ti=0;
                         break;
            case 3:   ti=1;
                         break;
            case 6:  ti=2;
                         break;
            case 9:   ti=3;
                         break;
            
         };

         a[movie1][ti]++;
      }  
  int max=-500; 
       for(int i=0; i<4; i++)
       {
          for(int j=0; j<4; j++)
          {
             if(i!=j)
             {
                for(int k=0; k<4; k++)
                {  int count=0;   
                       profit=0; 
                   
                   if((i!=k) && (k!=j))
                   {       int h=100;
                           b[0]=a[i][0];
                           b[1]=a[j][1];
                           b[2]=a[k][2];
                           b[3]=a[6-i-j-k][3];
                           sort(b,b+4);   
                           for(int l=3; l>=0; l--)
                           {
                                if(b[l]==0)
                                {count++;}
                                else
                                   {
                                      profit=profit+b[l]*h;
                                   }
                                 h-=25;
                                   
                           }

                           profit=profit-count*100;
                           if(profit>max)
                               max=profit;
                   }
                }
             }
          }
       }    
       profit2=profit2+max;
       cout<<max<<endl;
}   
cout<<profit2;
return(0);
}
