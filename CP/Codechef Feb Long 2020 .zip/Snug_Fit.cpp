#include<iostream>
#include<bits/stdc++.h>
using namespace std;
int main()
{
	ios_base::sync_with_stdio(false); cin.tie(NULL); cout.tie(NULL);

   long long int T,n,s=0;
      cin>>T;
   while(T--)
      {
         cin>>n;
         long long int A[1000000],B[1000000];
         for (int i=0; i<n; i++)
         {
               cin>>A[i];
         }
         sort(A,A+n);
       
         for (int i=0; i<n; i++)
         {
               cin>>B[i];
         }
           sort(B,B+n);
      
    s =0; 
    for(int i=0; i<n; i++)
   {
        if(A[i]<B[i])
            s+=A[i];
        else if(A[i]>B[i]) 
            s+=B[i];
       
   }
       
        cout<<s<<endl;
      }

return(0);
}
