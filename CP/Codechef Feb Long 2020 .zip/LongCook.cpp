#include <iostream>

using namespace std;
int main()
{
    long long int t,dif,q,l=0,y1,m1,y2,m2,fl=0,i,d,rem;
    cin>>t;
    while (t--)
    {
        cin>>m1>>y1;
        cin>>m2>>y2;
        if(m1>2)
        {
            y1++;
        }
        if(m2<2)
        {
            y2--;
        }
        dif = y2-y1;
        if(dif>=2000)
        {
            q=dif/2000;
            rem = dif%2000; 
            y1=y2-rem;
        }
        for(i = y1;i<=y2;i++)
        {
            if (i % 4 == 0)
            {
                if (i % 100 == 0)
                {
                    if (i % 400 == 0)
                        fl=1;
                    else
                        fl=0;
                }
                else
                    fl=1;
            }
            else
                fl=0;

            d = (1 + ((153 * (2 + 12 * ((14 - 2) / 12) - 3) + 2) / 5) +
            (365 * (i + 4800 - ((14 -2 ) / 12))) +
            ((i + 4800 - ((14 - 2) / 12)) / 4) -
            ((i + 4800 - ((14 - 2) / 12)) / 100) +
            ((i + 4800 - ((14 - 2) / 12)) / 400)  - 32045) % 7;
            if((d==6)&&fl==0)
            {
                l++;
            }
            if(d==5)
            {
                l++;
            }
            fl=0;
        }
        l = l + q*505;
        cout<<l<<endl;
        l=0;
        q=0;
    }
    return 0;
}