#include <bits/stdc++.h>

using namespace std;

int main() {
	    long long int n,m,r;  
	    cin>>n>>m>>r;
	    for(long long int i = 0; i<r;i++)
	        cin>>n>>m;

	   cout<<"1 1 0"<<endl;
	   
	}
	
