#include<bits/stdc++.h>
#include<algorithm>

using namespace std;

#define mp make_pair
#define pb push_back
#define ff first
#define ss second

const double pi=3.1415926535897932384626433832;
const long long mod=1e9+7;
//long long primeset[5000000]={};
typedef complex<double> cd;
typedef long long ll;
typedef double ld;
//#define For(i,0,n) for(long long i = 0 ; i<n ;i++)
//#define uppertolower if(isupper(a[i]))  {a[i] = a[i] + 32;}

/*void removeCharsFromString( string &str, char* charsToRemove ) {
   for ( unsigned int i = 0; i < strlen(charsToRemove); ++i ) {
      str.erase( remove(str.begin(), str.end(), charsToRemove[i]), str.end() ); }}*/

//atoi()- char array to integer typecast STL, changes original string, keep copy
//itoi() - int to char array typecast:  sprintf(str,"%d",value)
//============================================================================================================================================


int main()
{
	ios_base::sync_with_stdio(false); cin.tie(NULL); cout.tie(NULL);

long long int T,N,K; 
cin>>T;

while(T--)
{
     cin>>N>>K; 
     long long int A[100000],sum=0; 
       for(int i=0 ; i<N; i++)
       {       
               cin>>A[i];
               sum+=A[i]%K;  

       }
      cout<<sum%K<<endl;

}   

return(0);
}

