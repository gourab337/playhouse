#include<stdio.h>

int isRightX(long long x1, long long x2, long long y)
{  
  if((y*y) == -(x1*x2))
        return 1;
   else 
        return 0;
}

int isRightY(long long y1, long long y2, long long x)
{ 
   
   if ((y1*y2 ) == - (x*x))
        return 1;
   else 
        return 0;
}


int main()
{

long long T,m,n,flagx=0,flagy=0; 
scanf("%lld",&T);

while(T--)
{   flagx=0; flagy=0;
    scanf("%lld %lld",&n,&m);
    long long x[n],y[m];
    for(long long i=0; i<n; i++)
       {
            scanf("%lld",&x[i]);
            if(!(x[i]))
                flagx=1;
       }
    for(long long i=0; i<m ; i++)
       {
          scanf("%lld",&y[i]);
          if(!(y[i]))
                flagy=1;
       }
 long long right=0;
   for(long long i=0; i<n; i++)
   {  if(x[i]==0)
            continue;
      
       for(long long j=i; j<n; j++)
       {  if(x[j]==0)
               continue;
          
          for(long long k=0; k<m; k++)
            {   if (y[k]==0)
                   continue;
               if(isRightX(x[i],x[j],y[k]))
                   right++;
            }
       }
   }
   
   for(long long i=0; i<m; i++)
   {  if(y[i]==0)
          continue;
       
       for(long long j=i; j<m; j++)
       {  if(y[j]==0)
              continue;
          
          for(long long k=0; k<n; k++)
            {  if (x[k]==0)
                  continue;
               if(isRightY(y[i],y[j],x[k]))
                   right++;
            }
       }
   }
   if(flagx || flagy)
    right+=(n-flagx)*(m-flagy);
  
   printf("%lld",right);
   printf("\n");
   
}


return(0);
}
